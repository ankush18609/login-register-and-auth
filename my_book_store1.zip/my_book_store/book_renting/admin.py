from django.contrib import admin
from book_renting.models import book,renting
# Register your models here.
admin.site.register(book)
admin.site.register(renting)
